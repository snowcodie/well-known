<!-- Main Footer -->
  <footer class="no-print text-center text-info">
    <!-- To the right -->
    <!-- <div class="pull-right hidden-xs">
      Anything you want
    </div> -->
    <!-- Default to the left -->
    <small>
    	<b><?php echo e(config('app.name', 'ultimatePOS'), false); ?> - V<?php echo e(config('author.app_version'), false); ?> | Copyright &copy; <?php echo e(date('Y'), false); ?> All rights reserved.</b>
    </small>
</footer><?php /**PATH /home/srikethcom/tbr.sriketha.com/resources/views/layouts/partials/footer_pos.blade.php ENDPATH**/ ?>