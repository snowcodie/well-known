<!-- model id like project_id, user_id -->
<input type="hidden" name="notable_id" id="notable_id" value="<?php echo e($contact->id, false); ?>">
<!-- model name like App\User -->
<input type="hidden" name="notable_type" id="notable_type" value="App\Contact">
<div class="document_note_body">
</div><?php /**PATH /home/srikethcom/tbr.sriketha.com/resources/views/contact/partials/documents_and_notes_tab.blade.php ENDPATH**/ ?>