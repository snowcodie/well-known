<div class="pos-tab-content active">
    <div class="row">
        <div class="col-sm-4">
            
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <table class="table table-bordered table-striped" id="sell_table">
                <thead>
                    <tr>
                        <th><?php echo app('translator')->get('messages.action'); ?></th>
                        <th><?php echo app('translator')->get('messages.date'); ?></th>
                        <th><?php echo app('translator')->get('sale.invoice_no'); ?></th>
                        <th><?php echo app('translator')->get('sale.customer_name'); ?></th>
                        <th><?php echo app('translator')->get('lang_v1.contact_no'); ?></th>
                        <th><?php echo app('translator')->get('sale.location'); ?></th>
                        <th><?php echo app('translator')->get('sale.payment_status'); ?></th>
                        <th><?php echo app('translator')->get('lang_v1.payment_method'); ?></th>
                        <th><?php echo app('translator')->get('sale.total_amount'); ?></th>
                        <th><?php echo app('translator')->get('sale.total_paid'); ?></th>
                        <th><?php echo app('translator')->get('lang_v1.added_by'); ?></th>
                        <th><?php echo app('translator')->get('sale.sell_note'); ?></th>
                        <th><?php echo app('translator')->get('sale.staff_note'); ?></th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
</div><?php /**PATH /home/srikethcom/tbr.sriketha.com/Modules/Accounting/Providers/../Resources/views/transactions/partials/sales.blade.php ENDPATH**/ ?>